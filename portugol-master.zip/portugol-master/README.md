# portugol
Conceitos e exercícios de lógica de programação por meio da ferramenta Portugol studio da UNIVALI.

Baixe o [Portugol studio](http://downloads.sourceforge.net/project/portugolstudio/2.2/Multi-Plataforma/ps-2.2-multi-plataforma.zip?r=http%3A%2F%2Flite.acad.univali.br%2Fportugol%2F&ts=1476925187&use_mirror=nbtelecom), desempacote-o e instale-o em seu sistema operacional.

[Creative Commons Attribution 3.0 Unported (CC BY 3.0) License](http://creativecommons.org/licenses/by/3.0/)
